
class ApiController < ApplicationController
  include Authable
end
